const adminmodel= require("../model/adminmodel")
const User = require('../model/usermodel');
const Product = require('../model/productmodel');
const Order = require('../model/ordermodel'); 

const bcrypt=require('bcrypt')
  
const loadlogin=async(req,res)=>{
    res.render('admin/login')
}

const login=async(req,res)=>{
    try{
    const{username,password}=req.body
    const admin=await adminmodel.findOne({username})
    if(!admin)return res.render('admin/login',{message:"invalid credenitals"})
    const isMatch=await bcrypt.compare(password,admin.password)
    if(!isMatch) return res.render('admin/login',{message:"invalid credentials"})
         res.redirect('/admin/dashboard')
    }catch(error){
        res.send(error)

    }
}

// const loaddashboard= async(req,res)=>{
//     res.render('admin/dashboard')
// }

 
const loaddashboard= async (req, res) => {
    try {
      const totalUsers = await User.countDocuments();
      const totalProducts = await Product.countDocuments();
      const totalOrders = await Order.countDocuments();
      
      // Optionally calculate revenue
      const orders = await Order.find();
      const totalRevenue = orders.reduce((sum, order) => sum + order.totalPrice, 0);
  
      res.render('admin/dashboard', {
        totalUsers,
        totalProducts,
        totalOrders,
        totalRevenue,
      });
    } catch (error) {
      console.error(error);
      res.status(500).send('Server error');
    }
  };


  
// List all products
const getProducts = async (req, res) => {
    const products = await Product.find();
    res.render('admin/adminproducts', { products });
  };
  
  // Show add product form
  const getAddProduct = (req, res) => {
    res.render('admin/addproduct');
  };
  
  // Post add product
// const postAddProduct = async (req,res) => {
//   try {
//     const { name, description, price, category, image } = req.body;

//     const newProduct = new Product({
//       name,
//       description,
//       price,
//       category,
//       image, // This will be like "fruitItem1.png"
//     });

//     await newProduct.save();

//     res.redirect('/admin/dashboard'); // Or redirect to product list
//   } catch (error) {
//     console.log(error);
//     response.status(500).send("Error adding product");
//   }
// };

const postAddProduct = async (req, res) => {
  try {
    const { name, description, price, category } = req.body;
    const image = req.file.path; // Cloudinary image URL
    await Product.create({ name, description, price, category, image });
    res.redirect('/admin/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding product');
  }
};

  // Show edit product form
  const getEditProduct = async (req, res) => {
    const product = await Product.findById(req.params.id);
    res.render('admin/editproduct', { product });
  };
  
  // Handle update
  // const postEditProduct = async (req, res) => {
  //   try {
  //     const { name, description, price, image } = req.body;
  
  //     const updatedData = {
  //       name,
  //       description,
  //       price,
  //       image, // image from dropdown select
  //     };
  
  //     await Product.findByIdAndUpdate(req.params.id, updatedData);
  //     res.redirect('/admin/products');
  //   } catch (err) {
  //     console.error(err);
  //     res.status(500).send('Error updating product');
  // //   }
  // };
  const postEditProduct = async (req, res) => {
    try {
      const { name, description, price } = req.body;
      const updatedData = { name, description, price };
  
      if (req.file) {
        console.log('Uploaded file:', req.file);
        updatedData.image = req.file.path; // Cloudinary URL
      }
  
      await Product.findByIdAndUpdate(req.params.id, updatedData);
      res.redirect('/admin/products');
    } catch (err) {
      console.error(err);
      res.status(500).send('Error updating product');
    }
  };
  
  
  // Delete product
  const deleteProduct = async (req, res) => {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect('/admin/products');
  };

module.exports={
    login,
    loadlogin,
    loaddashboard,
    postAddProduct,
    getAddProduct ,
    getEditProduct ,
    postEditProduct ,
    deleteProduct,
    getProducts
}