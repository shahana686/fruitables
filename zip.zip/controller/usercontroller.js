const userSchema = require("../model/usermodel");
const Otp = require('../model/otpmodel');
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const saltrounds = 10;

const signupuser = async (req, res) => {
  try {
    
    const { email, PhoneNo, password, confirm } = req.body;
    const user = await userSchema.findOne({ email });
    if (user) {
      return res.render("user/signup", { message: "user already exits" });
    }

    if (password !== confirm) {
      return res.render("user/signup", { message: "password do not match" });
    }
    const hashedpassword = await bcrypt.hash(password, saltrounds);
    const newuser = new userSchema({
      email,
      PhoneNo,
      password: hashedpassword,
    });

    await newuser.save();
    //  console.log('✅ New User Saved:', newuser);
    res.render("user/signup", { success: " Signin Successfully" });
  } catch (error) {
    console.log(error);
    res.render("user/signup", { message: "wrong" });
  }
};
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await userSchema.findOne({ email });
    if (!user) {
      return res.render("user/login", { message: "user does not exit" });
    }
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.render("user/login", { message: "incorrect password" });
    }
    // Create JWT token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "1d",
    });

    // Set cookie
    res.cookie("jwt", token, {
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    });
    //res.render('user/index')
    res.redirect("/user/index");
  } catch (error) {
    console.log(error);
  }
};
const loadSignup = (req, res) => {
  res.render("user/signup");
};

const loadLogin = (req, res) => {
  res.render("user/login");
};

const loaduserindex = async (req, res) => {
  res.render("user/index", { user: req.user });
};
const loadcart = async (req, res) => {
  res.render("user/cart", { user: req.user });
};
const loadcheckout = async (req, res) => {
  res.render("user/checkout", { user: req.user });
};

//otp




 const sendOtp = async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ message: 'Phone number is required' });
  }

  const code = Math.floor(1000 + Math.random() * 9000).toString();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

  try {
    await Otp.deleteMany({ phone }); // Optional: remove old OTPs
    await Otp.create({ phone, code, expiresAt });

    console.log(`OTP for ${phone}: ${code}`); // Simulate sending SMS
    res.status(200).json({ message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Error sending OTP:', error);
    res.status(500).json({ message: 'Failed to send OTP' });
  }
};


const verifyOtp = async (req, res) => {
  try {
    const { phone, code } = req.body;

    const otpDoc = await Otp.findOne({ phone, code });
    if (!otpDoc || otpDoc.expiresAt < new Date()) {
      return res.status(400).json({ message: 'Invalid or expired OTP' });
    }

    let user = await User.findOne({ phone });
    if (!user) {
      user = await User.create({ phone }); // Empty profile
    }

    const token = jwt.sign({ userId: user._id }, 'your_secret_key', { expiresIn: '7d' });
    await Otp.deleteMany({ phone }); // Clean up OTPs

    res.status(200).json({ token, user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
module.exports = {
  signupuser,
  loadSignup,
  loadLogin,
  loaduserindex,
  loadcart,
  loadcheckout,
  loginUser,
  sendOtp,
  verifyOtp
};
