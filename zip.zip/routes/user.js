
const express=require('express')
const router=express.Router()
const usercontroller=require('../controller/usercontroller')
const authUser = require('../middleware/auth')





// router.get('/cart', (req, res) => {
//     res.render('user/cart');
// });

// router.get('/checkout', (req, res) => {
//     res.render('user/checkout'); 
// });

router.get('/testimonial', (req, res) => {
    res.render('user/testimonial');
});

router.get('/404', (req, res) => {
    res.render('user/404');
});

router.get('/contact', (req, res) => {
    res.render('user/contact');
});
  

router.get('/login',usercontroller.loadLogin)
router.post('/login',usercontroller.loginUser)
router.get('/signup',usercontroller.loadSignup)
router.post('/signup',usercontroller.signupuser)
router.get('/index',usercontroller.loaduserindex)
router.get('/cart',authUser,usercontroller.loadcart)
router.get('/checkout',authUser,usercontroller.loadcheckout)
router.post('/send-otp',usercontroller.sendOtp)
router.post('/verify-otp', usercontroller.verifyOtp);

module.exports=router
