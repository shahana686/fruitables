const express=require('express')
const router=express.Router()
const admincontroller=require('../controller/admincontroller')
const adminAuth = require('../middleware/adminauth');
const upload = require('../middleware/multer');



// router.get('/login',(req,res)=>{
//     res.render('admin/login')
// })
// router.post('/login',(req,res)=>{
//     res.render('admin/dashboard')
// })
// router.get('/login',(req,res)=>{
//     res.render('admin/dashboard')
// })

router.get('/login',admincontroller.loadlogin)
router.post('/login',admincontroller.login)
router.get('/dashboard',admincontroller.loaddashboard)
router.get('/products',  admincontroller.getProducts);
router.get('/product/add',admincontroller.getAddProduct);
router.post('/product/add',upload.single('image'),  admincontroller.postAddProduct);
router.get('/product/edit/:id', upload.single('image'), admincontroller.getEditProduct);
router.post('/product/edit/:id', admincontroller.postEditProduct);
router.get('/product/delete/:id',admincontroller.deleteProduct);


module.exports=router