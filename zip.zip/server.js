
const express=require("express")
const app=express()
const path=require('path')
const cookieParser=require('cookie-parser')


const userRoutes=require('./routes/user')
const adminRoutes=require('./routes/admin')
const connectdb = require('./db/connectdb')
require('dotenv').config();



// //view engine setup
app.set("views",path.join(__dirname,'views'))
app.set('view engine', 'hbs');


// app.use(express.static("public"))
app.use(express.static(path.join(__dirname, 'public')))


//convert data into json format
app.use(express.json())
app.use(express.urlencoded({extended:false}))

app.use(cookieParser());

app.use('/user',userRoutes)
app.use('/admin',adminRoutes)

connectdb()
 
const PORT=process.env.PORT

app.listen(PORT,()=>{
    console.log("server started");
    
})